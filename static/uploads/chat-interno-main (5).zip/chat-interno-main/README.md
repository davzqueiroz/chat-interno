# chat-interno
Chat Interno desenvolvido na empresa Parcol Parafusos com intuito de substituir o Spark que utiliza Firebase
