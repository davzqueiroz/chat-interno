import webbrowser, openpyxl as oppxl, time

planilha = oppxl.load_workbook('numeros.xlsx')
pagina = planilha['Plan1']

for cell in pagina['A']:
    webbrowser.open(f'http://api.whatsapp.com/send?1=pt_BR&phone=55{cell.value}', new=2)
    time.sleep(10)

# os.system('start www.youtube.com')
